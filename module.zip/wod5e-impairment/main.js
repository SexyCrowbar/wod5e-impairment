// main.js

const MODULE_ID = "wod5e-impairment";

// ============================================================
// CRIPPLING INJURY TABLE
// ============================================================
const INJURY_TABLE = [
  {
    key: 'stunned',
    range: [1, 6],
    bonuses: [],
    isStunned: true
  },
  {
    key: 'severeHeadTrauma',
    range: [7, 8],
    bonuses: [
      { value: -1, paths: ['physical'] },
      { value: -2, paths: ['mental'] }
    ]
  },
  {
    // 9-10: Broken limb OR Blinded — players decide per roll if the penalty applies.
    // Use the suppress toggle on the condition for rolls that are not affected.
    key: 'brokenBlinded',
    range: [9, 10],
    bonuses: [{ value: -3, paths: ['physical'] }]
  },
  {
    key: 'massiveWound',
    range: [11, 11],
    bonuses: [
      { value: -2, paths: ['physical'] },
      { value: -2, paths: ['social'] },
      { value: -2, paths: ['mental'] }
    ]
  },
  {
    key: 'crippled',
    range: [12, 12],
    bonuses: [{ value: -3, paths: ['physical'] }]
  },
  {
    key: 'death',
    range: [13, Infinity],
    bonuses: [],
    isDeath: true
  }
];

// ============================================================
// INJURY SETTINGS FORM
// ============================================================
class InjurySettingsForm extends FormApplication {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: 'wod5e-injury-settings',
      title: game.i18n.localize('WOD5E.Setting.injury.menuName'),
      template: `modules/${MODULE_ID}/templates/injury-settings.hbs`,
      width: 420
    });
  }

  getData() {
    const config = game.settings.get(MODULE_ID, 'injuryConfig');
    const injuries = INJURY_TABLE.map(entry => {
      const rangeStr = entry.range[1] === Infinity
        ? `${entry.range[0]}+`
        : entry.range[0] === entry.range[1]
          ? `${entry.range[0]}`
          : `${entry.range[0]}–${entry.range[1]}`;
      return {
        key: entry.key,
        label: `${game.i18n.localize(`WOD5E.Injury.${entry.key}.Name`)} (${rangeStr})`,
        pc: config.pc?.[entry.key] ?? false,
        npc: config.npc?.[entry.key] ?? false
      };
    });
    return {
      allPc: injuries.every(i => i.pc),
      allNpc: injuries.every(i => i.npc),
      injuries
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
    const form = html[0] ?? html;

    // Column header "select all" toggles
    form.querySelector('.pc-select-all').addEventListener('change', function () {
      form.querySelectorAll('input[name^="pc."]').forEach(cb => cb.checked = this.checked);
    });
    form.querySelector('.npc-select-all').addEventListener('change', function () {
      form.querySelectorAll('input[name^="npc."]').forEach(cb => cb.checked = this.checked);
    });
  }

  async _updateObject(event, formData) {
    const config = foundry.utils.expandObject(formData);
    await game.settings.set(MODULE_ID, 'injuryConfig', config);
  }
}

// ============================================================
// SETTINGS REGISTRATION
// ============================================================
Hooks.once("init", () => {
  // Single config object storing per-injury PC/NPC toggles
  game.settings.register(MODULE_ID, 'injuryConfig', {
    scope: 'world',
    config: false,
    type: Object,
    default: { pc: {}, npc: {} }
  });

  // Menu button in module settings
  game.settings.registerMenu(MODULE_ID, 'injurySettingsMenu', {
    name: 'WOD5E.Setting.injury.menuName',
    label: 'WOD5E.Setting.injury.menuLabel',
    hint: 'WOD5E.Setting.injury.menuHint',
    icon: 'fas fa-skull-crossbones',
    type: InjurySettingsForm,
    restricted: true
  });
});

// ============================================================
// MAIN INITIALIZATION
// ============================================================
Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Initializing WOD5E Impairment Patch`);

  if (!game.modules.get("lib-wrapper")?.active) {
    ui.notifications.error(`[${MODULE_ID}] Requires the 'libWrapper' module. Please install and activate it.`);
    return;
  }

  // Impairment penalties injection (existing functionality)
  libWrapper.register(
    MODULE_ID,
    "WOD5E.WoDActorBase.prototype.prepareItems",
    injectImpairmentToItems,
    "WRAPPER"
  );

  // Crippling injury buttons injection (new functionality)
  libWrapper.register(
    MODULE_ID,
    "WOD5E.WoDActorBase.prototype._onRender",
    injectInjuryButtons,
    "WRAPPER"
  );
});

// Helper: get the injury config category for an actor
function getActorCategory(actor) {
  return actor.type === 'spc' ? 'npc' : 'pc';
}

// Helper: check if a specific injury is enabled for an actor's category
function isInjuryEnabled(injuryKey, category) {
  const config = game.settings.get(MODULE_ID, 'injuryConfig');
  return config[category]?.[injuryKey] ?? false;
}

// ============================================================
// IMPAIRMENT PENALTIES INJECTION
// ============================================================
async function injectImpairmentToItems(wrapped, sheetData) {
  await wrapped(sheetData);

  const data = sheetData.system;
  if (!data) return;

  const dynamicBonuses = [];

  // --- Check for Impaired Health ---
  if (data?.health?.max > 0 && !data.frenzyActive) {
    let healthDamage = (data.health.superficial || 0) + (data.health.aggravated || 0);
    let maxHealth = data.health.max;

    // --- Take Crinos health bonus into account ---
    if (data.activeForm === 'crinos' && data.crinosHealth) {
      healthDamage += (data.crinosHealth.superficial || 0) + (data.crinosHealth.aggravated || 0);
      maxHealth += data.crinosHealth.max || 0;
    }

    if (healthDamage >= maxHealth) {
      dynamicBonuses.push({
        source: game.i18n?.localize('WOD5E.ImpairedHealth') || "Impaired Health",
        value: -2,
        paths: ['physical'],
        activeWhen: { check: 'always' }
      });
    }
  }

  // --- Check for Impaired Willpower ---
  if (data?.willpower?.max > 0) {
    const wpDamage = (data.willpower.superficial || 0) + (data.willpower.aggravated || 0);

    if (wpDamage >= data.willpower.max) {
      dynamicBonuses.push({
        source: game.i18n?.localize('WOD5E.ImpairedWillpower') || "Impaired Willpower",
        value: -2,
        paths: ['social', 'mental'],
        activeWhen: { check: 'always' }
      });
    }
  }

  if (dynamicBonuses.length > 0) {
    if (!data.itemModifiers) data.itemModifiers = [];
    data.itemModifiers.push(...dynamicBonuses);
  }
}

// ============================================================
// UI INJECTION — Crippling Injury Buttons
// ============================================================
async function injectInjuryButtons(wrapped, ...args) {
  await wrapped(...args);

  const element = this.element;
  if (!element) return;

  // Guard against duplicate injection on re-renders
  if (element.querySelector('.crippling-injury-controls')) return;

  const actor = this.actor;
  const category = getActorCategory(actor);

  // Check that at least one injury type is enabled for this actor's category
  const anyEnabled = INJURY_TABLE.some(i => isInjuryEnabled(i.key, category));
  if (!anyEnabled) return;

  const healthEl = element.querySelector('.resource.flex-group-center.health');
  if (!healthEl) return; // Actor type has no health bar (e.g. Group actors)

  const fieldSection = healthEl.closest('.field-section');
  if (!fieldSection) return;

  // Roll Injury is only active when health tracker is fully marked
  const data = actor.system;
  let healthFull = false;

  if (data?.health?.max > 0 && !data.frenzyActive) {
      let healthDamage = (data.health.superficial || 0) + (data.health.aggravated || 0);
      let maxHealth = data.health.max;

      // --- Take Crinos health bonus into account ---
      if (data.activeForm === 'crinos' && data.crinosHealth) {
        healthDamage += (data.crinosHealth.superficial || 0) + (data.crinosHealth.aggravated || 0);
        maxHealth += data.crinosHealth.max || 0;
      }

      if (healthDamage >= maxHealth) {
        healthFull = true;
      }
    } 

  // Heal Injury is only active when there are healable injuries (excludes 'crippled')
  const hasHealableInjuries = actor.items.some(
    i => i.type === 'condition' && i.flags?.[MODULE_ID]?.isCripplingInjury === true
      && i.flags[MODULE_ID].injuryKey !== 'crippled'
  );

  const controls = document.createElement('div');
  controls.className = 'crippling-injury-controls flexrow';

  if (healthFull) {
    const rollBtn = document.createElement('button');
    rollBtn.className = 'crippling-roll-btn';
    rollBtn.type = 'button';
    rollBtn.innerHTML = `<i class="fa-regular fa-bone-break"></i>`;
    rollBtn.addEventListener('click', (e) => { e.preventDefault(); rollCripplingInjury(actor); });
    controls.appendChild(rollBtn);
  }

  if (hasHealableInjuries) {
    const healBtn = document.createElement('button');
    healBtn.className = 'crippling-heal-btn';
    healBtn.type = 'button';
    healBtn.innerHTML = `<i class="fa-regular fa-hand-holding-medical"></i>`;
    healBtn.addEventListener('click', (e) => { e.preventDefault(); healCripplingInjury(actor); });
    controls.appendChild(healBtn);
  }

  // Only inject the container if at least one button is visible
  if (controls.children.length > 0) {
    fieldSection.parentNode.insertBefore(controls, fieldSection);
  }
}

// ============================================================
// ROLL CRIPPLING INJURY
// ============================================================
async function rollCripplingInjury(actor) {
  const category = getActorCategory(actor);
  const aggravated = actor.system?.health?.aggravated ?? 0;

  const roll = await new Roll('1d10').evaluate();
  const d10Result = roll.total;
  const total = d10Result + aggravated;

  const injury = getInjuryForTotal(total, category);
  if (!injury) {
    ui.notifications.warn(`[${MODULE_ID}] All injury types are disabled in module settings.`);
    return;
  }

  const injuryName = game.i18n.localize(`WOD5E.Injury.${injury.key}.Name`);
  const injuryDesc = game.i18n.localize(`WOD5E.Injury.${injury.key}.Desc`);
  const speaker = ChatMessage.getSpeaker({ actor });

  // Post roll breakdown to chat
  await ChatMessage.create({
    speaker,
    content: `
      <div class="wod5e-crippling-injury-roll">
        <h3 class="injury-title">${game.i18n.localize('WOD5E.CripplingInjuryRoll')}</h3>
        <div class="injury-breakdown">
          (d10: <strong>${d10Result}</strong>)+(${game.i18n.localize('WOD5E.AggravatedModifier')}: <strong>+${aggravated}</strong>)= <strong>${total}</strong>
        </div>
        <div class="injury-result">
          <strong>${injuryName}</strong>
          <p>${injuryDesc}</p>
        </div>
      </div>
    `
  });

  // Death — chat message already posted, no condition created
  if (injury.isDeath) return;

  // Stunned — show choice dialog
  if (injury.isStunned) {
    await foundry.applications.api.DialogV2.wait({
      window: { title: `${injuryName} — ${actor.name}` },
      content: `<p>${game.i18n.localize('WOD5E.StunnedChoice')}</p>`,
      buttons: [
        {
          action: 'willpower',
          label: game.i18n.localize('WOD5E.StunnedSpendWillpower'),
          default: true,
          callback: async () => {
            const sup = actor.system.willpower?.superficial || 0;
            const agg = actor.system.willpower?.aggravated || 0;
            const max = actor.system.willpower?.max || 0;
            const trackFull = (sup + agg) >= max;

            if (trackFull) {
              // Track is full — convert a superficial to aggravated
              const update = { 'system.willpower.aggravated': Math.min(agg + 1, max) };
              if (sup > 0) update['system.willpower.superficial'] = sup - 1;
              await actor.update(update);
            } else {
              // Track has room — add 1 superficial
              await actor.update({ 'system.willpower.superficial': Math.min(sup + 1, max) });
            }

            await ChatMessage.create({
              speaker,
              content: `<p>${game.i18n.format('WOD5E.StunnedSpentWillpower', { name: actor.name })}</p>`
            });
          }
        },
        {
          action: 'loseTurn',
          label: game.i18n.localize('WOD5E.StunnedLoseTurn'),
          callback: async () => {
            await ChatMessage.create({
              speaker,
              content: `<p>${game.i18n.format('WOD5E.StunnedLostTurn', { name: actor.name })}</p>`
            });
          }
        }
      ]
    });
    return;
  }

  // All other injuries — create a condition item on the actor
  await actor.createEmbeddedDocuments('Item', [{
    name: injuryName,
    type: 'condition',
    flags: {
      [MODULE_ID]: {
        isCripplingInjury: true,
        injuryKey: injury.key,
        timestamp: Date.now()
      }
    },
    system: {
      description: injuryDesc,
      bonuses: injury.bonuses.map(b => ({
        source: injuryName,
        value: String(b.value),
        paths: b.paths,
        displayWhenInactive: false,
        activeWhen: { check: 'always', path: '', value: '' }
      })),
      suppressed: false
    }
  }]);
}

// Returns the injury entry for a given roll total, skipping disabled entries (bumps upward)
function getInjuryForTotal(total, category) {
  const startIndex = INJURY_TABLE.findIndex(i => total >= i.range[0] && total <= i.range[1]);
  if (startIndex === -1) return null;

  for (let i = startIndex; i < INJURY_TABLE.length; i++) {
    const entry = INJURY_TABLE[i];
    if (isInjuryEnabled(entry.key, category)) return entry;
  }
  return null;
}

// ============================================================
// HEAL CRIPPLING INJURY
// ============================================================
async function healCripplingInjury(actor) {
  const injuries = actor.items.filter(
    i => i.type === 'condition' && i.flags?.[MODULE_ID]?.isCripplingInjury === true
      && i.flags[MODULE_ID].injuryKey !== 'crippled'
  );

  if (injuries.length === 0) {
    // Check if only 'crippled' conditions remain
    const hasCrippled = actor.items.some(
      i => i.type === 'condition' && i.flags?.[MODULE_ID]?.isCripplingInjury === true
        && i.flags[MODULE_ID].injuryKey === 'crippled'
    );
    ui.notifications.warn(game.i18n.localize(
      hasCrippled ? 'WOD5E.CrippledCannotHeal' : 'WOD5E.NoInjuryToHeal'
    ));
    return;
  }

  // Remove the injury with the lowest table value first
  const tableOrder = INJURY_TABLE.map(e => e.key);
  injuries.sort((a, b) => {
    const idxA = tableOrder.indexOf(a.flags[MODULE_ID].injuryKey);
    const idxB = tableOrder.indexOf(b.flags[MODULE_ID].injuryKey);
    return idxA - idxB;
  });
  const targetInjury = injuries[0];

  await actor.deleteEmbeddedDocuments('Item', [targetInjury.id]);

  const speaker = ChatMessage.getSpeaker({ actor });
  await ChatMessage.create({
    speaker,
    content: `<p>${game.i18n.format('WOD5E.CripplingInjuryHealed', { name: actor.name, injury: targetInjury.name })}</p>`
  });
}
