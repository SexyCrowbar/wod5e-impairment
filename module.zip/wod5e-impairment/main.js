// main.js

const MODULE_ID = "wod5e-impairment"; // Replace with your actual module ID
Hooks.once("ready", () => {
  console.log(`${MODULE_ID} | Initializing WOD5E Impairment Patch`);
  if (!game.modules.get("lib-wrapper")?.active) {
    ui.notifications.error(`[${MODULE_ID}] Requires the 'libWrapper' module. Please install and activate it.`);
    return;
  }
  // Wrap the exact function where the WOD5e system builds the itemModifiers array
  libWrapper.register(
    MODULE_ID,
    "WOD5E.WoDActorBase.prototype.prepareItems",
    injectImpairmentToItems,
    "WRAPPER"
  );
});
/**
 * Wrapper function for prepareItems.
 */
async function injectImpairmentToItems(wrapped, sheetData) {
  // 1. Let the system do its normal routine of grabbing all items and placing them in sheetData.system.itemModifiers
  await wrapped(sheetData);
  // 2. Now we inject our own dynamic modifiers!
  const data = sheetData.system;
  if (!data) return;
  const dynamicBonuses = [];
  // --- Check for Impaired Health ---
  if (data?.health?.max > 0) {
    let healthDamage = (data.health.superficial || 0) + (data.health.aggravated || 0);
    let maxHealth = data.health.max;
    if (data.activeForm === 'crinos' && data.crinosHealth) {
      healthDamage += (data.crinosHealth.superficial || 0) + (data.crinosHealth.aggravated || 0);
      maxHealth += data.crinosHealth.max || 0;
    }
    if (healthDamage >= maxHealth) {
      dynamicBonuses.push({
        source: game.i18n?.localize('WOD5E.ImpairedHealth') || "Impaired Health",
        value: -2,
        paths: ['physical'],
        activeWhen: { check: 'always' } 
      });
    }
  }
  // --- Check for Impaired Willpower ---
  if (data?.willpower?.max > 0) {
    const wpDamage = (data.willpower.superficial || 0) + (data.willpower.aggravated || 0);
    
    if (wpDamage >= data.willpower.max) {
      dynamicBonuses.push({
        source: game.i18n?.localize('WOD5E.ImpairedWillpower') || "Impaired Willpower",
        value: -2,
        paths: ['social', 'mental'],
        activeWhen: { check: 'always' }
      });
    }
  }
  // Bind the newly generated penalties directly to the actor's active modifiers list
  if (dynamicBonuses.length > 0) {
    if (!data.itemModifiers) data.itemModifiers = [];
    data.itemModifiers.push(...dynamicBonuses);
  }
}